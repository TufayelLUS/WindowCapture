﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace Print_Screen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            makeSavePath();
            checkBox1.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                WindowState = FormWindowState.Minimized;
            }
            if (textBox1.Text != String.Empty)
            {
                int delay = Convert.ToInt32(textBox1.Text);
                System.Threading.Thread.Sleep(delay * 1000);
            }
            PrintScreen();
            WindowState = FormWindowState.Normal;
            Form2 f = new Form2();
            f.Show();
        }

        private void PrintScreen()
        {

            Bitmap printscreen = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            Graphics graphics = Graphics.FromImage(printscreen as Image);

            graphics.CopyFromScreen(0, 0, 0, 0, printscreen.Size);

            string time = DateTime.Now.ToString(@"h-mm-ss tt (dd-mm-yy)");
            string filename = @"Screenshots/Screenshot - " + time +".png";
            printscreen.Save(filename, ImageFormat.Png);

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
        private void makeSavePath()
        {
            System.IO.Directory.CreateDirectory("Screenshots");
        }
    }
}
